# rubocop:disable Naming/FileName
require 'cfn-nag/cfn_nag'
require 'cfn-nag/violation'
require 'cfn-nag/rule_dumper'
# rubocop:enable Naming/FileName
